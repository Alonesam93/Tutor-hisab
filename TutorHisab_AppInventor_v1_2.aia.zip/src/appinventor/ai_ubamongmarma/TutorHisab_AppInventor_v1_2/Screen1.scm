#|
$JSON
{"YaVersion":"239","Source":"Form","Properties":{"$Name":"Screen1","$Type":"Form","$Version":"32","AppName":"Tutor Hisab","Title":"Tutor Hisab","AboutScreen":"Tutor Hisab - Student fee and payment tracker","AlignHorizontal":"3","AlignVertical":"2","Scrollable":"False","Sizing":"Responsive","ShowStatusBar":"True","Theme":"AppTheme.Light.DarkActionBar","Uuid":"0","$Components":[{"$Name":"WebViewer1","$Type":"WebViewer","$Version":"11","Width":"-2","Height":"-2","HomeUrl":"file:\/\/\/android_asset\/Tutor_Hisab_v1.html","FollowLinks":"True","UsesLocation":"False","Uuid":"1001"}]}}
|#